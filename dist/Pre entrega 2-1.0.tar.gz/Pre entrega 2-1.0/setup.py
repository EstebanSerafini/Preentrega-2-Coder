from setuptools import setup

setup(

    name='Pre entrega 2' ,
    version='1.0' ,
    description='Pre entrega 2 Python' ,
    author='Esteban Serafini' ,
    author_email='estebanserafini@gmail.com' ,

    packages=['Preentregas', 'Preentregas.Preentrega1', 'Preentregas.Preentrega2'],
    scripts=[]

)